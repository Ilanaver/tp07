--1
select top 3 UPPER(nombre),domicilio,email from cliente order by nombre;
--2
select nombre, precioUnitario, IDArticulo from articulo where precioUnitario >10 and precioUnitario<100;
--3
select nombre,email,domicilio,activo from proveedor where nombre like 'f%' and email like '%arg%' and activo = 'true';
--4
select fecha,fkCliente,descuento,total from factura where descuento > 0 or total<15000;
--5
update provincia set pais='Argentina' where pais!='Argentina';
--6
update articulo set stockActual=stockActual+10 where fkRubro=1;
--7
update articulo set precioUnitario=precioUnitario+precioUnitario*0.2 where fkRubro=3 and fkProveedor=1;
--8
delete from provincia where pais='Espa�a';
--9
delete from factura where fkCliente=3;
--10
insert into rubro (nombre) values ('Deportes');
--11
insert into provincia (nombre,pais) values ('Montevideo', 'Uruguay');
--12
insert into cliente (nombre,domicilio,email,fkProvincia,fkIva) values ('Carlos Rodiguez','Avellaneda 1213', 'crodiguez73@gmail.com',27,5);
--13
insert into proveedor(nombre, domicilio,email,fkProvincia,activo) values('milka','juncal 3000','milkaarg@gmail.com',2,'true');
--14-1
select * from delivery where medioTransporte='moto';
--14-2
delete from delivery where medioTransporte='auto';
--14-3
insert into delivery(nombre,medioTransporte) values ('Carlos','bici');
